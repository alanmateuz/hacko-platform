import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import ts from 'typescript';
import * as domain from '../lib/domain.mjs';
const require=createRequire(import.meta.url), sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');for(const f of fs.readdirSync(new URL('../drizzle/',import.meta.url)).filter(f=>f.endsWith('.sql')).sort())sql.exec(fs.readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));
const db={prepare(query){let values=[];return {bind(...v){values=v;return this},async first(){return sql.prepare(query).get(...values)||null},async all(){return {results:sql.prepare(query).all(...values)}},async run(){const r=sql.prepare(query).run(...values);return {meta:{changes:Number(r.changes)}}}}},async batch(statements){sql.exec('BEGIN');try{const result=[];for(const s of statements)result.push(await s.run());sql.exec('COMMIT');return result}catch(e){sql.exec('ROLLBACK');throw e}}};
let user=null;
function compiled(path,imports){const js=ts.transpileModule(fs.readFileSync(new URL(path,import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const mod={exports:{}};vm.runInNewContext(js,{module:mod,exports:mod.exports,require:x=>imports[x]??require(x),Response,Request,URL,crypto,console,AbortSignal,fetch});return mod.exports;}
const validation=compiled('../lib/validation.ts',{});
const api=compiled('../app/api/hacko/route.ts',{'cloudflare:workers':{env:{DB:db}},'../../chatgpt-auth':{getChatGPTUser:async()=>user},'../../../lib/validation':validation,'../../../lib/domain.mjs':domain});
const as=id=>{user=id?{userId:id,email:id+'@example.test',displayName:id}:null};
async function post(body){const r=await api.POST(new Request('https://hacko.test/api/hacko',{method:'POST',headers:{origin:'https://hacko.test','content-type':'application/json'},body:JSON.stringify(body)}));return {status:r.status,body:await r.json()}}
async function get(action,id=''){const r=await api.GET(new Request('https://hacko.test/api/hacko?action='+action+'&id='+id));return {status:r.status,body:await r.json()}}
const day=n=>new Date(Date.now()+n*86400000).toISOString();
let org,event,team;
test('fase 01: autenticação, isolamento e jornada de evento/equipe',async()=>{
 as(null);assert.equal((await post({op:'organization',data:{name:'Empresa'}})).status,401);
 for(const id of ['owner','other','alice','bob','carol','dave']){as(id);assert.equal((await post({op:'profile',data:{name:id,bio:'',skills:'Java, UX',interests:'',city:'Fortaleza',availability:'Noites',linkedin:'',github:'',visible:id!=='carol'}})).status,200)}
 as('owner');org=(await post({op:'organization',data:{name:'Organização teste',description:''}})).body.id;
 const data={title:'Hackathon teste',summary:'Evento sintético de teste funcional.',rules:'Regras para participação no evento teste.',eligibility:'Participantes de teste',format:'Online',city:'Online',venue:'Plataforma online',theme:'IA',starts_at:day(10),ends_at:day(11),opens_at:day(-1),closes_at:day(9),capacity:3,team_min:2,team_max:2,image:0,source:''};
 event=(await post({op:'event.save',orgId:org,data})).body.id;assert.ok(event);
 assert.equal((await get('bootstrap')).body.events.length,0);
 as('other');assert.equal((await get('manage',event)).status,403);assert.equal((await post({op:'event.save',id:event,data})).status,403);assert.equal((await get('event',event)).status,404);
 as('owner');assert.equal((await post({op:'event.publish',id:event})).status,400);assert.equal((await post({op:'event.publish',id:event,confirm:true})).status,200);
 for(const id of ['alice','bob','carol']){as(id);assert.equal((await post({op:'register',id:event,accept:true})).status,200)}
 as('dave');assert.equal((await post({op:'register',id:event,accept:true})).status,409);
 as('alice');assert.equal((await post({op:'register',id:event,accept:true})).body.already,true);
 const publiclyVisible=(await get('event',event)).body.participants;assert.ok(!publiclyVisible.some(p=>p.id==='carol'));assert.ok(publiclyVisible.every(p=>!('email'in p)));
 team=(await post({op:'team.create',data:{event_id:event,name:'Equipe teste',skills:'React',description:''}})).body.id;assert.ok(team);
 assert.equal((await post({op:'team.create',data:{event_id:event,name:'Outra equipe',skills:'',description:''}})).status,409);assert.equal(sql.prepare('SELECT count(*) n FROM teams').get().n,1);
 as('other');assert.equal((await post({op:'team.leave',id:team})).status,403);assert.equal((await post({op:'team.dissolve',id:team,confirm:true})).status,403);
 as('bob');assert.equal((await post({op:'team.request',id:team})).status,200);
 as('alice');const request=(await get('team',team)).body.requests[0];assert.equal((await post({op:'team.respond',id:team,requestId:request.id,accept:true})).status,200);
 as('carol');await post({op:'team.request',id:team});as('alice');const req=(await get('team',team)).body.requests.find(r=>r.user_id==='carol');assert.equal((await post({op:'team.respond',id:team,requestId:req.id,accept:true})).status,409);
 as('owner');assert.equal((await post({op:'team.confirm',id:team})).status,200);const managed=(await get('manage',event)).body;assert.equal(managed.registrations.length,3);assert.equal(managed.teams[0].members,2);
 assert.equal((await post({op:'event.save',id:event,data:{...data,capacity:2}})).status,409);
 as('bob');assert.equal((await post({op:'cancel',id:event})).status,400);assert.equal((await post({op:'team.leave',id:team})).status,200);assert.equal(sql.prepare('SELECT status FROM teams WHERE id=?').get(team).status,'forming');assert.equal((await post({op:'cancel',id:event})).status,200);
 as('owner');assert.equal((await post({op:'team.confirm',id:team})).status,409);
 const bad=await api.POST(new Request('https://hacko.test/api/hacko',{method:'POST',headers:{origin:'https://evil.test','content-type':'application/json'},body:'{}'}));assert.equal(bad.status,403);
});
test('matching: 20, 100 e 300 participantes, sem omissões ou duplicidades',()=>{for(const size of [20,100,300])for(const [min,max]of [[2,3],[3,5],[5,7]]){const people=Array.from({length:size},(_,i)=>({id:String(i).padStart(4,'0'),skills:i%2?'Java, React':'UX, Produto',availability:i%7===0?'':i%3?'Noites':'Integral'}));const result=domain.suggestTeams(people,min,max);assert.deepEqual(result,domain.suggestTeams([...people].reverse(),min,max));const ids=[...result.teams.flatMap(t=>t.members),...result.unassigned.map(p=>p.id)];assert.equal(new Set(ids).size,size);assert.equal(ids.length,size);for(const t of result.teams){assert.ok(t.members.length>=min&&t.members.length<=max);assert.equal(new Set(t.members.map(id=>people.find(p=>p.id===id).availability)).size,1)}}});
test('matching: rejeita IDs duplicados e limites inválidos',()=>{assert.throws(()=>domain.suggestTeams([{id:'a'},{id:'a'}],2,4));assert.throws(()=>domain.suggestTeams([],5,2))});
test('catálogo: filtros combinados e acentuação',()=>{const events=[{title:'Inovação',summary:'Teste',theme:'IA',city:'Fortaleza',format:'Online',starts_at:'2027-01-05T10:00:00Z'}];assert.equal(domain.searchCatalog(events,{q:'inovacao',city:'forta',format:'Online',from:'2027-01-01',to:'2027-01-06'}).length,1);assert.equal(domain.searchCatalog(events,{format:'Presencial'}).length,0)});
